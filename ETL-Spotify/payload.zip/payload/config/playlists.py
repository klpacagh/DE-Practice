def spotify_playlists():
    playlists = {'drum_and_bass_2021': 'spotify:playlist:068WHS0zOWsqvn2uIBYb5D'}
    return playlists


def personal_playlists():
    playlists = {'drive_hood': 'spotify:playlist:1uM1laLmdeCMRQoYC1gybB'}
    return playlists
